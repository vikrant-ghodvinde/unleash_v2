

const TemplateTwo = () => {
  return (
    <div>TemplateTwo</div>
  )
}

export default TemplateTwo